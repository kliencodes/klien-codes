import type { Metadata } from "next";
import { siteConfig } from "@/config/site";
import { AboutPreview } from "@/components/sections/AboutPreview";
import { TechStackMatrix } from "@/components/interactive/TechStackMatrix";
import { FinalCtaBand } from "@/components/sections/FinalCtaBand";
import { Reveal } from "@/components/motion/Reveal";

export const metadata: Metadata = {
  title: `About ${siteConfig.founderName}`,
  description: siteConfig.description,
};

export default function AboutPage() {
  return (
    <>
      <AboutPreview />
      <section className="mx-auto max-w-7xl px-6 py-20 lg:px-12">
        <Reveal>
          <span className="font-mono text-xs font-semibold tracking-widest text-[var(--accent-text)] uppercase">
            CORE STACK // VERIFIED TOOLING
          </span>
          <h2 className="mt-3 mb-8 font-display text-3xl font-semibold text-[var(--text-primary)]">
            Technologies &amp; Platforms
          </h2>
          <TechStackMatrix />
        </Reveal>
      </section>
      <FinalCtaBand />
    </>
  );
}
