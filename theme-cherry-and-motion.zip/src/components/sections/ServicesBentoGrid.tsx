import Link from "next/link";
import {
  ArrowRight,
  Cloud,
  Compass,
  Cpu,
  Database,
  GitBranch,
  ShieldCheck,
} from "lucide-react";
import { services, type ServiceItem } from "@/content/services";
import { Reveal } from "@/components/motion/Reveal";

function ServiceIcon({ name }: { name: ServiceItem["iconName"] }) {
  const cls = "h-5 w-5 text-[var(--accent-text)]";
  switch (name) {
    case "Cloud":
      return <Cloud className={cls} />;
    case "GitBranch":
      return <GitBranch className={cls} />;
    case "ShieldCheck":
      return <ShieldCheck className={cls} />;
    case "Cpu":
      return <Cpu className={cls} />;
    case "Database":
      return <Database className={cls} />;
    case "Compass":
      return <Compass className={cls} />;
  }
}

export function ServicesBentoGrid() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-20 lg:px-12 lg:py-28">
      <Reveal className="max-w-2xl">
        <span className="font-mono text-xs font-semibold tracking-widest text-[var(--accent-text)] uppercase">
          01 // CORE CAPABILITIES
        </span>
        <h2 className="mt-3 font-display text-3xl font-semibold text-[var(--text-primary)] sm:text-4xl">
          End-to-End Technical Advisory &amp; Hands-On Execution
        </h2>
        <p className="mt-3 text-base text-[var(--text-secondary)]">
          Six specialized IT consultancy pillars engineered to eliminate
          infrastructure risk, accelerate deployments, and keep 100% ownership
          with your internal team.
        </p>
      </Reveal>

      <div className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-12">
        {services.map((service, idx) => (
          <Reveal
            key={service.id}
            delay={idx * 0.05}
            className={service.featured ? "lg:col-span-6" : "lg:col-span-6 xl:col-span-3"}
          >
            <Link
              href={`/services/${service.slug}`}
              className="group relative flex h-full flex-col justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface-1)] p-6 transition-all duration-300 hover:-translate-y-1 hover:border-[var(--accent-primary)]/70 hover:bg-[var(--bg-surface-2)]/70 active:scale-[0.99] lg:p-7"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[var(--text-muted)]">
                    {service.index} //
                  </span>
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface-2)]">
                    <ServiceIcon name={service.iconName} />
                  </div>
                </div>

                <h3 className="mt-5 font-display text-xl font-semibold text-[var(--text-primary)]">
                  {service.title}
                </h3>

                <p className="mt-2.5 text-sm leading-relaxed text-[var(--text-secondary)]">
                  {service.shortSummary}
                </p>
              </div>

              <div className="mt-6 space-y-4">
                <div className="flex flex-wrap gap-1.5">
                  {service.techStack.slice(0, 4).map((tech) => (
                    <span
                      key={tech}
                      className="rounded-full border border-[var(--border-subtle)] bg-[var(--bg-canvas)] px-2.5 py-0.5 font-mono text-[11px] text-[var(--text-secondary)]"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="flex items-center gap-1.5 font-mono text-xs font-medium text-[var(--accent-text)]">
                  <span>View Architecture &amp; Scope</span>
                  <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            </Link>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
