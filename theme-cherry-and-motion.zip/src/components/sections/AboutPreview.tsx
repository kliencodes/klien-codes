import Link from "next/link";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { siteConfig } from "@/config/site";
import { Reveal } from "@/components/motion/Reveal";

const principles = [
  "Direct principal execution—never handed off to junior account layers.",
  "Documentation-first engineering: RFCs, ADRs, and zero vendor lock-in.",
  "Pragmatic security and FinOps built into day-one architecture decisions.",
];

export function AboutPreview() {
  return (
    <section className="border-y border-[var(--border-subtle)] bg-[var(--bg-surface-1)]/60 py-20 lg:py-28">
      <div className="mx-auto max-w-4xl px-6 lg:px-12">
        <Reveal>
          <span className="font-mono text-xs font-semibold tracking-widest text-[var(--accent-text)] uppercase">
            06 // PRINCIPAL CONSULTANT
          </span>
          <h2 className="mt-3 font-display text-3xl font-semibold text-[var(--text-primary)] sm:text-4xl">
            Work Directly With the Architect Building Your Systems
          </h2>
        </Reveal>

        <Reveal delay={0.08}>
          <div className="mt-8 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-canvas)] p-7 sm:p-10">
            <p className="text-base leading-relaxed text-[var(--text-secondary)] sm:text-lg">
              Over the past {siteConfig.experienceYears} years, I&apos;ve
              partnered with founders, CTOs, and engineering teams to design
              resilient cloud infrastructure, untangle legacy technical debt,
              and ship secure software at scale. When you engage{" "}
              <strong className="text-[var(--text-primary)]">
                {siteConfig.brandName}
              </strong>
              , you work directly with the principal engineer designing,
              reviewing, and automating your stack from day one.
            </p>

            <ul className="mt-7 space-y-3 border-t border-[var(--border-subtle)] pt-6">
              {principles.map((p) => (
                <li
                  key={p}
                  className="flex items-start gap-2.5 text-sm text-[var(--text-secondary)]"
                >
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[var(--accent-text)]" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>

            <div className="mt-6 flex flex-wrap gap-2">
              {siteConfig.certifications.map((cert) => (
                <span
                  key={cert}
                  className="rounded-full border border-[var(--border-subtle)] bg-[var(--bg-surface-1)] px-3 py-1 font-mono text-[11px] text-[var(--text-secondary)]"
                >
                  {cert}
                </span>
              ))}
            </div>

            {/* Classic Typographic Sign-Off */}
            <div className="mt-8 flex flex-col justify-between gap-4 border-t border-[var(--border-subtle)] pt-6 sm:flex-row sm:items-end">
              <div>
                <p className="font-display text-xl font-semibold text-[var(--text-primary)]">
                  — {siteConfig.founderName}
                </p>
                <p className="mt-0.5 font-mono text-xs text-[var(--accent-text)]">
                  {siteConfig.founderTitle} · {siteConfig.brandName}
                </p>
              </div>

              <Link
                href="/about"
                className="inline-flex items-center gap-2 font-mono text-xs font-semibold text-[var(--text-primary)] transition-colors hover:text-[var(--accent-text)]"
              >
                <span>FULL BACKGROUND &amp; STACK</span>
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
