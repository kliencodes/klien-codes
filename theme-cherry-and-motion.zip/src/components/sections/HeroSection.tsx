import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { siteConfig } from "@/config/site";
import { AvailabilityBadge } from "@/components/brand/AvailabilityBadge";
import { LiveArchitectureDiagram } from "@/components/interactive/LiveArchitectureDiagram";
import { Reveal } from "@/components/motion/Reveal";

const ecosystemBadges = [
  "AWS",
  "MICROSOFT AZURE",
  "GOOGLE CLOUD",
  "KUBERNETES",
  "TERRAFORM",
  "DOCKER",
  "GITHUB ACTIONS",
  "SOC 2 / ISO 27001",
];

export function HeroSection() {
  return (
    <section className="hero-glow relative overflow-hidden border-b border-[var(--border-subtle)]">
      <div className="bg-blueprint-grid pointer-events-none absolute inset-0 opacity-35 [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_78%)]" />

      <div className="relative mx-auto max-w-7xl px-6 pt-16 pb-20 lg:px-12 lg:pt-24 lg:pb-24">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12">
          <div className="space-y-6 lg:col-span-7">
            <Reveal delay={0.02} y={12}>
              <AvailabilityBadge showSuffix />
            </Reveal>

            <Reveal delay={0.08} y={16}>
              <h1 className="font-display text-4xl font-bold tracking-tight text-[var(--text-primary)] sm:text-5xl lg:text-[56px] lg:leading-[1.08]">
                {siteConfig.tagline}
              </h1>
            </Reveal>

            <Reveal delay={0.14} y={16}>
              <p className="max-w-2xl text-base leading-relaxed text-[var(--text-secondary)] sm:text-lg">
                I partner with founders, CTOs, and engineering leaders to design
                cloud-native architectures, automate DevOps pipelines, harden
                security postures, and modernize legacy systems—from blueprint to
                production.
              </p>
            </Reveal>

            <Reveal delay={0.2} y={16}>
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <Link
                  href="/contact"
                  className="inline-flex h-12 items-center gap-2 rounded-lg bg-[var(--accent-primary)] px-6 text-sm font-semibold text-[#FAFAFA] shadow-lg shadow-red-950/30 transition-all hover:-translate-y-0.5 hover:bg-[var(--accent-primary-hover)] active:scale-[0.98]"
                >
                  <span>Book a Technical Discovery Call</span>
                  <ArrowRight className="h-4 w-4" />
                </Link>

                <Link
                  href="/work"
                  className="inline-flex h-12 items-center gap-2 rounded-lg border border-[var(--border-strong)] bg-[var(--bg-surface-1)] px-6 text-sm font-medium text-[var(--text-primary)] transition-all hover:border-[var(--accent-primary)] active:scale-[0.98]"
                >
                  <span>Explore Case Studies</span>
                </Link>
              </div>
            </Reveal>
          </div>

          <Reveal delay={0.18} y={20} className="lg:col-span-5">
            <LiveArchitectureDiagram />
          </Reveal>
        </div>

        <Reveal delay={0.26} y={12}>
          <div className="mt-16 border-t border-[var(--border-subtle)] pt-8">
            <p className="font-mono text-[11px] font-medium tracking-widest text-[var(--text-muted)] uppercase">
              TECHNOLOGY ECOSYSTEMS &amp; STANDARDS
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-3">
              {ecosystemBadges.map((item) => (
                <span
                  key={item}
                  className="font-mono text-xs font-medium tracking-wider text-[var(--text-secondary)] opacity-80 transition-opacity hover:opacity-100"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
