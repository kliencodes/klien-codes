export interface ServiceItem {
  id: string;
  index: string;
  slug: string;
  title: string;
  shortSummary: string;
  fullDescription: string;
  iconName:
    | "Cloud"
    | "GitBranch"
    | "ShieldCheck"
    | "Cpu"
    | "Database"
    | "Compass";
  featured: boolean;
  deliverables: string[];
  techStack: string[];
  idealFor: string[];
  typicalTimeline: string;
  sampleArchitectureSteps: string[];
}

export const services: ServiceItem[] = [
  {
    id: "cloud-architecture",
    index: "01",
    slug: "cloud-architecture",
    title: "Cloud Architecture & Migration",
    shortSummary:
      "Design fault-tolerant, cost-optimized cloud environments across AWS, Azure, and GCP—or migrate legacy workloads with zero-downtime cutover plans.",
    fullDescription:
      "Whether you are scaling past an early-stage single-region setup or migrating critical workloads off legacy virtual machines, I architect multi-AZ, security-hardened cloud foundations with transparent FinOps cost controls.",
    iconName: "Cloud",
    featured: true,
    deliverables: [
      "Well-Architected Infrastructure Review & Risk Matrix",
      "Multi-Account Landing Zones & Network Topology",
      "Zero-Downtime Migration & Cutover Runbooks",
      "Cloud FinOps & Compute Cost Optimization Audit",
    ],
    techStack: ["AWS", "Azure", "GCP", "Terraform", "Kubernetes", "Cloudflare"],
    idealFor: [
      "SaaS teams preparing for enterprise uptime SLAs",
      "Organizations experiencing unpredictable cloud spend",
      "Teams migrating monoliths or on-prem servers to cloud-native stacks",
    ],
    typicalTimeline: "2–8 Weeks",
    sampleArchitectureSteps: [
      "Baseline workload profiling, latency mapping & dependency discovery",
      "Target VPC/Landing Zone design with private subnets and least-privilege IAM",
      "Automated IaC provisioning and shadow-traffic validation",
      "Blue/green DNS cutover with rollback triggers and post-launch telemetry",
    ],
  },
  {
    id: "devops-iac",
    index: "02",
    slug: "devops-iac",
    title: "DevOps, CI/CD & IaC Automation",
    shortSummary:
      "Eliminate manual deployments and environment drift with reproducible Infrastructure as Code, automated test gates, and observable release pipelines.",
    fullDescription:
      "Manual server clicks and fragile deployment scripts slow down engineering velocity and trigger avoidable outages. I build reproducible Terraform/OpenTofu modules, fast CI/CD workflows, and end-to-end observability stacks.",
    iconName: "GitBranch",
    featured: true,
    deliverables: [
      "Modular Terraform / OpenTofu Infrastructure Repositories",
      "GitHub Actions / GitLab CI Automated Release Pipelines",
      "Container Orchestration (Kubernetes, EKS, ECS, Docker)",
      "Unified Logging, Metrics & Distributed Tracing (OpenTelemetry)",
    ],
    techStack: ["Terraform", "Docker", "Kubernetes", "GitHub Actions", "Prometheus", "Grafana"],
    idealFor: [
      "Engineering teams stuck with slow or error-prone manual releases",
      "Startups needing staging/production parity without ops bottlenecks",
      "Growing orgs standardizing infrastructure across multiple repositories",
    ],
    typicalTimeline: "2–6 Weeks",
    sampleArchitectureSteps: [
      "Audit existing build, test, and deployment bottlenecks",
      "Codify compute, networking, and secrets into versioned IaC modules",
      "Implement automated CI checks, container scanning, and preview environments",
      "Instrument OpenTelemetry dashboards, SLO alerts, and incident runbooks",
    ],
  },
  {
    id: "cybersecurity-devsecops",
    index: "03",
    slug: "cybersecurity-devsecops",
    title: "Cybersecurity & DevSecOps",
    shortSummary:
      "Embed security into every layer of your stack—from IAM least-privilege policies and container scanning to compliance-ready audit controls.",
    fullDescription:
      "Security shouldn't be a last-minute blocker before an enterprise deal closes. I help teams harden cloud perimeters, automate SAST/DAST and SBOM checks inside CI/CD, and implement practical controls aligned with SOC 2 and ISO 27001.",
    iconName: "ShieldCheck",
    featured: false,
    deliverables: [
      "Cloud Security Posture & IAM Least-Privilege Audit",
      "Threat Modeling & Zero-Trust Network Segmentation",
      "Automated Pipeline SAST, Dependency & Container Scanning",
      "SOC 2 / ISO 27001 Technical Control Readiness",
    ],
    techStack: ["OIDC", "Vault", "Trivy", "WAF", "Zero-Trust", "SOC 2"],
    idealFor: [
      "B2B startups preparing for enterprise security questionnaires",
      "Teams adopting automated DevSecOps gates in CI/CD",
      "Organizations eliminating static credentials and over-permissive IAM roles",
    ],
    typicalTimeline: "2–5 Weeks",
    sampleArchitectureSteps: [
      "Attack-surface inventory across cloud accounts, repos, and secrets",
      "Replace long-lived keys with short-lived OIDC federation and secret managers",
      "Enforce branch protection, signed commits, and automated vulnerability gates",
      "Deliver compliance-ready evidence exports and remediation playbooks",
    ],
  },
  {
    id: "software-modernization",
    index: "04",
    slug: "software-modernization",
    title: "Software Architecture & Modernization",
    shortSummary:
      "Decompose brittle monoliths, resolve database bottlenecks, and establish clean API contracts so your engineering team ships faster with fewer outages.",
    fullDescription:
      "When legacy codebases become too risky to touch, product velocity stalls. I design pragmatic strangler-fig modernization roadmaps, optimize high-load database schemas, and establish resilient API and event-driven patterns.",
    iconName: "Cpu",
    featured: false,
    deliverables: [
      "System Architecture Blueprints & RFC Documentation",
      "API Contract, Caching & Event-Driven Architecture Design",
      "Incremental Legacy Refactoring Roadmaps (Zero Big-Bang Risk)",
      "Database Query, Indexing & Throughput Profiling",
    ],
    techStack: ["TypeScript", "Node.js", "Go", "PostgreSQL", "Redis", "Kafka"],
    idealFor: [
      "Teams struggling with cascading outages or slow database queries",
      "Product orgs decoupling tightly bound legacy modules",
      "Founders validating system design before major v2 rewrites",
    ],
    typicalTimeline: "3–10 Weeks",
    sampleArchitectureSteps: [
      "Profile production bottlenecks, slow queries, and coupling hotspots",
      "Author Architecture Decision Records (ADRs) with explicit trade-offs",
      "Introduce clean service boundaries, async queues, and caching layers",
      "Pair with internal engineers to deliver the first modernized vertical slice",
    ],
  },
  {
    id: "data-ai-infrastructure",
    index: "05",
    slug: "data-ai-infrastructure",
    title: "Data Infrastructure & AI Integration",
    shortSummary:
      "Build reliable data pipelines and production-safe AI/LLM integrations with strict governance, retrieval accuracy, and predictable compute costs.",
    fullDescription:
      "Move beyond fragile prototypes into observable, governed data and AI systems. I architect scalable ETL/ELT pipelines, hybrid vector/relational retrieval architectures (RAG), and cost-controlled LLM gateways.",
    iconName: "Database",
    featured: false,
    deliverables: [
      "Automated ETL/ELT & Data Warehouse Architecture",
      "Production RAG & Enterprise AI Integration Blueprints",
      "LLM Guardrails, Evaluation Harnesses & Cost Telemetry",
      "Data Privacy, PII Redaction & Access Governance",
    ],
    techStack: ["Python", "PostgreSQL / pgvector", "dbt", "Snowflake", "OpenTelemetry"],
    idealFor: [
      "Companies moving AI proofs-of-concept into secure production",
      "Teams consolidating fragmented SaaS data into clean analytics pipelines",
      "Engineering leaders needing strict data privacy and token cost controls",
    ],
    typicalTimeline: "3–8 Weeks",
    sampleArchitectureSteps: [
      "Audit data sources, lineage, quality gaps, and privacy boundaries",
      "Design ingestion pipelines and governed analytical/vector storage",
      "Implement retrieval evaluation benchmarks, caching, and fallback routing",
      "Deploy monitoring for latency, drift, and per-tenant compute budgets",
    ],
  },
  {
    id: "fractional-cto-audits",
    index: "06",
    slug: "fractional-cto-audits",
    title: "Fractional CTO & Technical Audits",
    shortSummary:
      "Independent, senior technical due diligence for leadership teams navigating vendor selection, architecture sign-offs, scaling hires, or M&A prep.",
    fullDescription:
      "Get principal-level technical judgment without the overhead of a full-time executive hire. I provide candid architecture reviews, vendor evaluations, technical due diligence, and ongoing engineering leadership mentorship.",
    iconName: "Compass",
    featured: false,
    deliverables: [
      "Executive Technical Due Diligence & Architecture Audits",
      "Weekly Architecture Review Board & RFC Sign-Off",
      "Build-vs-Buy & Third-Party Vendor Evaluations",
      "Engineering Team Structure & Senior Hiring Rubrics",
    ],
    techStack: ["RFCs / ADRs", "FinOps", "SLOs", "Vendor RFPs", "Engineering Strategy"],
    idealFor: [
      "Non-technical or product-focused founders scaling an engineering team",
      "CTOs wanting an unbiased principal-level sounding board",
      "Investors or leadership teams conducting pre-investment technical checks",
    ],
    typicalTimeline: "1-Week Audit or Monthly Retainer",
    sampleArchitectureSteps: [
      "Stakeholder alignment on business milestones, runway, and risk tolerance",
      "Comprehensive review of architecture, cloud bills, CI/CD, and team rituals",
      "Executive readout with prioritized 30/60/90-day remediation roadmap",
      "Ongoing advisory check-ins, RFC reviews, and leadership enablement",
    ],
  },
];

export function getServiceBySlug(slug: string): ServiceItem | undefined {
  return services.find((service) => service.slug === slug);
}
