export interface FaqItem {
  question: string;
  answer: string;
}

export const faqItems: FaqItem[] = [
  {
    question: "Do you only advise, or do you also write production code and IaC?",
    answer:
      "Both. Every engagement can be scoped as pure architectural advisory and audits, or hands-on implementation writing production Terraform, CI/CD pipelines, and backend architecture alongside your internal engineers.",
  },
  {
    question: "Will we be locked into your consultancy after handover?",
    answer:
      "Never. Everything is built using standard, open tooling (Terraform/OpenTofu, GitHub Actions, standard cloud primitives) accompanied by Architecture Decision Records (ADRs), runbooks, and team walkthroughs so your team owns 100% of the stack.",
  },
  {
    question: "Can you work under an NDA and follow our security policies?",
    answer:
      "Yes. Mutual NDAs, least-privilege IAM access, hardware-backed MFA, and compliance-aligned workflows are standard practice across every client engagement.",
  },
  {
    question: "How do you collaborate with distributed or international teams?",
    answer:
      "I work asynchronously via structured RFCs, Git pull requests, and concise written/video updates, paired with scheduled overlap hours for live architecture reviews and demos.",
  },
  {
    question: "What happens during the initial 30-minute discovery call?",
    answer:
      "It is a zero-pitch technical conversation. You walk through your current stack, bottlenecks, and upcoming milestones; I share candid initial observations and outline whether a focused audit or build makes sense.",
  },
  {
    question: "How quickly can we get started?",
    answer:
      "Depending on current availability, focused Architecture & Security Audits typically kick off within 5 to 10 business days of scope alignment.",
  },
];
