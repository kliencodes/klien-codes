export interface EngagementModel {
  id: string;
  name: string;
  badge?: string;
  highlighted?: boolean;
  bestFor: string;
  typicalScope: string;
  pricingDisplay: string;
  deliverables: string[];
  ctaLabel: string;
}

export interface ProcessPhase {
  phase: string;
  title: string;
  duration: string;
  summary: string;
  output: string;
}

export const engagementModels: EngagementModel[] = [
  {
    id: "audit",
    name: "Architecture & Security Audit",
    bestFor:
      "Teams needing an objective second opinion, cloud cost audit, or clear roadmap before committing to a build.",
    typicalScope: "1–2 Weeks · Fixed Scope",
    pricingDisplay: "Fixed Fee · Custom Quote",
    deliverables: [
      "Full infrastructure, codebase & security posture review",
      "Prioritized Risk Matrix & FinOps savings report",
      "Target-state architecture diagram & 90-day roadmap",
      "60-minute executive & engineering team readout",
    ],
    ctaLabel: "Request an Audit",
  },
  {
    id: "implementation",
    name: "End-to-End Implementation",
    badge: "RECOMMENDED",
    highlighted: true,
    bestFor:
      "Companies executing a cloud migration, DevOps/IaC overhaul, security hardening, or new system architecture build.",
    typicalScope: "4–12 Weeks · Milestone-Based",
    pricingDisplay: "Milestone-Based · Scoped Upfront",
    deliverables: [
      "Signed-off RFC & Architecture Blueprint",
      "Production Terraform/IaC, CI/CD & application code",
      "Observability dashboards, alerts & security gates",
      "Complete ADRs, runbooks & team handover sessions",
    ],
    ctaLabel: "Scope an Implementation",
  },
  {
    id: "retainer",
    name: "Fractional Principal Advisory",
    bestFor:
      "Growing startups and engineering leaders needing ongoing CTO/Architect oversight without a full-time executive hire.",
    typicalScope: "Monthly Retainer · Flexible Cadence",
    pricingDisplay: "Monthly Retainer · Cancel Anytime",
    deliverables: [
      "Weekly architecture reviews & RFC / PR sign-off",
      "Async Slack/Teams access for critical technical decisions",
      "Vendor evaluations & technical hiring calibration",
      "Quarterly cloud cost, reliability & security health checks",
    ],
    ctaLabel: "Inquire About Advisory",
  },
];

export const processPhases: ProcessPhase[] = [
  {
    phase: "PHASE 01",
    title: "Discovery & System Audit",
    duration: "Week 1",
    summary:
      "Deep-dive into business goals, current infrastructure, codebases, security gaps, and cloud cost drivers.",
    output: "Diagnostic Audit & Risk Matrix",
  },
  {
    phase: "PHASE 02",
    title: "Architecture Blueprint & RFC",
    duration: "Week 2",
    summary:
      "Design target-state diagrams, explicit trade-off analyses, security controls, and a phased delivery roadmap.",
    output: "Signed-Off Technical Specification",
  },
  {
    phase: "PHASE 03",
    title: "Iterative Build & Automation",
    duration: "Execution",
    summary:
      "Hands-on delivery via Infrastructure as Code, automated test gates, and weekly stakeholder demos.",
    output: "Production-Ready Systems & Pipelines",
  },
  {
    phase: "PHASE 04",
    title: "Handover, Runbooks & Enablement",
    duration: "Closeout",
    summary:
      "Comprehensive documentation, Architecture Decision Records (ADRs), team walkthroughs, and post-launch checks.",
    output: "100% Ownership · Zero Lock-In",
  },
];
