import { z } from "zod";
import { siteConfig } from "@/config/site";
import { faqItems } from "@/content/faq";

export const contactFormSchema = z.object({
  services: z
    .array(z.string())
    .min(1, "Select at least one consultancy area."),
  engagementModel: z.string().min(1, "Select a preferred engagement model."),
  timeline: z.string().min(1, "Select your target timeline."),
  budgetRange: z.string().min(1, "Select an estimated budget band."),
  name: z.string().min(2, "Please enter your name."),
  email: z.string().email("Please enter a valid work email address."),
  company: z.string().optional(),
  brief: z
    .string()
    .min(20, "Share at least a brief 20+ character summary of your technical goals or bottlenecks.")
    .max(3000, "Please keep the initial brief under 3,000 characters."),
  website: z.string().max(0).optional(), // Honeypot anti-spam field
});

export type ContactFormValues = z.infer<typeof contactFormSchema>;

export function getOrganizationJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    name: siteConfig.brandName,
    url: siteConfig.domainUrl,
    email: siteConfig.contactEmail,
    description: siteConfig.description,
    founder: {
      "@type": "Person",
      name: siteConfig.founderName,
      jobTitle: siteConfig.founderTitle,
    },
    areaServed: "Worldwide",
  };
}

export function getPersonJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "Person",
    name: siteConfig.founderName,
    jobTitle: siteConfig.founderTitle,
    url: `${siteConfig.domainUrl}/about`,
    worksFor: {
      "@type": "Organization",
      name: siteConfig.brandName,
    },
    sameAs: [
      siteConfig.socialLinks.github,
      siteConfig.socialLinks.linkedin,
      siteConfig.socialLinks.x,
    ],
  };
}

export function getFaqJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqItems.map((item) => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: item.answer,
      },
    })),
  };
}
