export interface NavItem {
  label: string;
  href: string;
  description?: string;
}

export const mainNav: NavItem[] = [
  { label: "Services", href: "/services", description: "6 IT consultancy capabilities & stack" },
  { label: "Work", href: "/work", description: "Case studies & reference architectures" },
  { label: "Process", href: "/process", description: "Delivery protocol & engagement models" },
  { label: "About", href: "/about", description: "Principal consultant bio & principles" },
  { label: "Insights", href: "/insights", description: "Technical checklists & ADRs" },
];

export const footerColumns = {
  services: [
    { label: "Cloud Architecture", href: "/services/cloud-architecture" },
    { label: "DevOps & IaC Automation", href: "/services/devops-iac" },
    { label: "Cybersecurity & DevSecOps", href: "/services/cybersecurity-devsecops" },
    { label: "Software Modernization", href: "/services/software-modernization" },
    { label: "Data & AI Infrastructure", href: "/services/data-ai-infrastructure" },
    { label: "Fractional CTO & Audits", href: "/services/fractional-cto-audits" },
  ],
  company: [
    { label: "Selected Work", href: "/work" },
    { label: "Delivery Process", href: "/process" },
    { label: "About Principal", href: "/about" },
    { label: "Technical Insights", href: "/insights" },
    { label: "Start a Project", href: "/contact" },
  ],
};
