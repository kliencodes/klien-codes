export interface SiteConfig {
  temporaryMode: boolean;
  brandName: string;
  shortName: string;
  founderName: string;
  founderTitle: string;
  experienceYears: string;
  tagline: string;
  description: string;
  domainUrl: string;
  contactEmail: string;
  locationTz: string;
  availabilityStatus: string;
  calBookingUrl: string;
  socialLinks: {
    github: string;
    linkedin: string;
    x: string;
  };
  certifications: string[];
  assets: {
    logoDark: string;
    logoLight: string;
    logoMark: string;
    founderPortrait: string;
    workspaceContext: string;
    ogDefault: string;
  };
}

/**
 * SINGLE SOURCE OF TRUTH FOR YOUR BRAND IDENTITY
 * Swap these temporary values with your real name, domain, email, and links whenever ready.
 */
export const siteConfig: SiteConfig = {
  temporaryMode: true,
  brandName: "Kestrel Systems Advisory",
  shortName: "Kestrel",
  founderName: "Aarav Mehta",
  founderTitle: "Principal Cloud & IT Solutions Architect",
  experienceYears: "8+",
  tagline:
    "Resilient Cloud, Security & Systems Architecture—Engineered Without Agency Bloat.",
  description:
    "Independent IT consultancy partnering with founders, CTOs, and engineering teams on cloud architecture, DevOps automation, DevSecOps hardening, and legacy modernization.",
  domainUrl:
    process.env.NEXT_PUBLIC_SITE_URL || "https://kestrelsystems.example",
  contactEmail: "hello@kestrelsystems.example",
  locationTz: "India (IST / UTC+5:30) · Serving Global Clients",
  availabilityStatus: "Accepting New Clients · Q1 2027",
  calBookingUrl:
    process.env.NEXT_PUBLIC_CAL_LINK || "https://cal.com/kestrel-advisory/30min",
  socialLinks: {
    github: "https://github.com/kestrel-systems-example",
    linkedin: "https://linkedin.com/in/kestrel-systems-example",
    x: "https://x.com/kestrel_sys_ex",
  },
  certifications: [
    "AWS Solutions Architect (Placeholder)",
    "Certified Kubernetes Administrator (Placeholder)",
    "Terraform Associate (Placeholder)",
  ],
  assets: {
    logoDark: "/assets/logo/logo-full-dark.svg",
    logoLight: "/assets/logo/logo-full-light.svg",
    logoMark: "/assets/logo/logo-mark.svg",
    founderPortrait: "/assets/photos/founder-portrait.webp",
    workspaceContext: "/assets/photos/workspace-context.webp",
    ogDefault: "/assets/og/og-default.png",
  },
};
