import Link from "next/link";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { siteConfig } from "@/config/site";

const principles = [
  "Direct principal execution—never handed off to junior account layers.",
  "Documentation-first engineering: RFCs, ADRs, and zero vendor lock-in.",
  "Pragmatic security and FinOps built into day-one architecture decisions.",
];

export function AboutPreview() {
  return (
    <section className="border-y border-[var(--border-subtle)] bg-[var(--bg-surface-1)]/60 py-20 lg:py-28">
      <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-12 px-6 lg:grid-cols-12 lg:px-12">
        <div className="lg:col-span-5">
          <div className="relative overflow-hidden rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-canvas)] p-2">
            <img
              src={siteConfig.assets.founderPortrait}
              alt={`${siteConfig.founderName} — ${siteConfig.founderTitle}`}
              width={600}
              height={750}
              className="aspect-[4/5] w-full rounded-xl object-cover"
            />
          </div>
        </div>

        <div className="space-y-6 lg:col-span-7">
          <span className="font-mono text-xs font-semibold tracking-widest text-[var(--accent-primary)] uppercase">
            06 // PRINCIPAL CONSULTANT
          </span>
          <h2 className="font-display text-3xl font-semibold text-[var(--text-primary)] sm:text-4xl">
            Work Directly With the Architect Building Your Systems
          </h2>
          <p className="text-base leading-relaxed text-[var(--text-secondary)]">
            I&apos;m <strong className="text-[var(--text-primary)]">{siteConfig.founderName}</strong>,
            founder of {siteConfig.brandName}. Over the past{" "}
            {siteConfig.experienceYears} years, I&apos;ve helped engineering
            teams and founders design reliable cloud infrastructure, untangle
            technical debt, and ship secure software at scale.
          </p>

          <ul className="space-y-3 pt-1">
            {principles.map((p) => (
              <li
                key={p}
                className="flex items-start gap-2.5 text-sm text-[var(--text-secondary)]"
              >
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[var(--accent-primary)]" />
                <span>{p}</span>
              </li>
            ))}
          </ul>

          <div className="flex flex-wrap gap-2 pt-2">
            {siteConfig.certifications.map((cert) => (
              <span
                key={cert}
                className="rounded-full border border-[var(--border-subtle)] bg-[var(--bg-canvas)] px-3 py-1 font-mono text-[11px] text-[var(--text-secondary)]"
              >
                {cert}
              </span>
            ))}
          </div>

          <div className="pt-2">
            <Link
              href="/about"
              className="inline-flex items-center gap-2 font-mono text-xs font-semibold text-[var(--accent-primary)] hover:underline"
            >
              <span>READ FULL BACKGROUND &amp; PHILOSOPHY</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
