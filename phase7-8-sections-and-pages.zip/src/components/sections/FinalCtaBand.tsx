"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowRight, Check, Copy } from "lucide-react";
import { siteConfig } from "@/config/site";
import { copyToClipboard } from "@/lib/utils";

export function FinalCtaBand() {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    const ok = await copyToClipboard(siteConfig.contactEmail);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <section className="mx-auto max-w-7xl px-6 pb-24 lg:px-12">
      <div className="bg-blueprint-grid relative overflow-hidden rounded-3xl border border-[var(--border-strong)] bg-[var(--bg-surface-1)] p-8 text-center sm:p-14">
        <span className="font-mono text-xs font-semibold tracking-widest text-[var(--accent-primary)] uppercase">
          INITIATE // TECHNICAL DISCOVERY
        </span>
        <h2 className="mx-auto mt-3 max-w-2xl font-display text-3xl font-bold text-[var(--text-primary)] sm:text-4xl">
          Ready to De-Risk Your Next Technical Milestone?
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-base text-[var(--text-secondary)]">
          Book a 30-minute technical discovery call or send over your project
          brief—expect a direct response from {siteConfig.founderName} within 1
          business day.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
          <Link
            href="/contact"
            className="inline-flex h-12 items-center gap-2 rounded-lg bg-[var(--accent-primary)] px-6 text-sm font-semibold text-[#090B10] transition-colors hover:bg-[var(--accent-primary-hover)]"
          >
            <span>Schedule 30-Min Discovery Call</span>
            <ArrowRight className="h-4 w-4" />
          </Link>

          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex h-12 cursor-pointer items-center gap-2 rounded-lg border border-[var(--border-strong)] bg-[var(--bg-canvas)] px-5 font-mono text-xs font-medium text-[var(--text-primary)] transition-colors hover:border-[var(--accent-primary)]"
          >
            {copied ? (
              <>
                <Check className="h-4 w-4 text-[var(--status-success)]" />
                <span>Copied {siteConfig.contactEmail}</span>
              </>
            ) : (
              <>
                <Copy className="h-4 w-4 text-[var(--accent-primary)]" />
                <span>Email {siteConfig.contactEmail}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </section>
  );
}
