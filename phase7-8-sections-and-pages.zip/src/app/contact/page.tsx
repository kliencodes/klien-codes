import type { Metadata } from "next";
import { Suspense } from "react";
import { Mail, MapPin, ShieldCheck } from "lucide-react";
import { siteConfig } from "@/config/site";
import { AvailabilityBadge } from "@/components/brand/AvailabilityBadge";
import { ContactIntakeForm } from "@/components/interactive/ContactIntakeForm";

export const metadata: Metadata = {
  title: "Start a Project / Book Call",
  description:
    "Send a technical project brief or book a 30-minute architecture discovery call.",
};

export default function ContactPage() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-16 lg:px-12 lg:py-24">
      <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
        <div className="space-y-6 lg:col-span-5">
          <AvailabilityBadge />
          <h1 className="font-display text-4xl font-bold text-[var(--text-primary)]">
            Start a Technical Conversation
          </h1>
          <p className="text-base leading-relaxed text-[var(--text-secondary)]">
            Share your infrastructure goals, bottlenecks, or timeline using the
            scoping brief—or jump straight onto the calendar for a 30-minute
            discovery call with {siteConfig.founderName}.
          </p>

          <div className="space-y-4 border-t border-[var(--border-subtle)] pt-6 text-sm text-[var(--text-secondary)]">
            <div className="flex items-center gap-3">
              <Mail className="h-4 w-4 text-[var(--accent-primary)]" />
              <span className="font-mono text-xs text-[var(--text-primary)]">
                {siteConfig.contactEmail}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <MapPin className="h-4 w-4 text-[var(--accent-primary)]" />
              <span>{siteConfig.locationTz}</span>
            </div>
            <div className="flex items-center gap-3">
              <ShieldCheck className="h-4 w-4 text-[var(--status-success)]" />
              <span>Mutual NDA available prior to sharing sensitive architectures</span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-7">
          <Suspense
            fallback={
              <div className="h-96 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface-1)] p-8 font-mono text-xs text-[var(--text-muted)]">
                LOADING_INTAKE_FORM...
              </div>
            }
          >
            <ContactIntakeForm />
          </Suspense>
        </div>
      </div>
    </section>
  );
}
