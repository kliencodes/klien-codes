import type { Metadata } from "next";
import { siteConfig } from "@/config/site";
import { AboutPreview } from "@/components/sections/AboutPreview";
import { TechStackMatrix } from "@/components/interactive/TechStackMatrix";
import { FinalCtaBand } from "@/components/sections/FinalCtaBand";

export const metadata: Metadata = {
  title: `About ${siteConfig.founderName}`,
  description: siteConfig.description,
};

export default function AboutPage() {
  return (
    <>
      <AboutPreview />
      <section className="mx-auto max-w-7xl px-6 py-20 lg:px-12">
        <div className="overflow-hidden rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-canvas)]">
          <img
            src={siteConfig.assets.workspaceContext}
            alt="Systems engineering blueprint workspace"
            width={1920}
            height={1080}
            className="aspect-[16/9] w-full object-cover"
          />
        </div>

        <div className="mt-16">
          <span className="font-mono text-xs font-semibold tracking-widest text-[var(--accent-primary)] uppercase">
            CORE STACK // VERIFIED TOOLING
          </span>
          <h2 className="mt-3 mb-8 font-display text-3xl font-semibold text-[var(--text-primary)]">
            Technologies &amp; Platforms
          </h2>
          <TechStackMatrix />
        </div>
      </section>
      <FinalCtaBand />
    </>
  );
}
