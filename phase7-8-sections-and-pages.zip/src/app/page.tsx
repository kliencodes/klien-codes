import { getAllCaseStudies } from "@/lib/mdx";
import { HeroSection } from "@/components/sections/HeroSection";
import { ServicesBentoGrid } from "@/components/sections/ServicesBentoGrid";
import { ArchitectureShowcase } from "@/components/sections/ArchitectureShowcase";
import { CaseStudyGrid } from "@/components/sections/CaseStudyGrid";
import { ProcessTimeline } from "@/components/sections/ProcessTimeline";
import { EngagementModels } from "@/components/sections/EngagementModels";
import { AboutPreview } from "@/components/sections/AboutPreview";
import { FaqAccordion } from "@/components/sections/FaqAccordion";
import { FinalCtaBand } from "@/components/sections/FinalCtaBand";

export default function HomePage() {
  const caseStudies = getAllCaseStudies();

  return (
    <>
      <HeroSection />
      <ServicesBentoGrid />
      <ArchitectureShowcase />
      <CaseStudyGrid items={caseStudies} />
      <ProcessTimeline />
      <EngagementModels showEstimator />
      <AboutPreview />
      <FaqAccordion />
      <FinalCtaBand />
    </>
  );
}
