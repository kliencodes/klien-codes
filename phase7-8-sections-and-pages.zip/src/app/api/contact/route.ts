import { NextResponse } from "next/server";
import { Resend } from "resend";
import { contactFormSchema } from "@/lib/schema";
import { siteConfig } from "@/config/site";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = contactFormSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message || "Invalid form data." },
        { status: 400 }
      );
    }

    const data = parsed.data;

    // Silent accept if honeypot field was filled by a bot
    if (data.website && data.website.length > 0) {
      return NextResponse.json({ ok: true });
    }

    const apiKey = process.env.RESEND_API_KEY;
    const toEmail = process.env.CONTACT_TO_EMAIL || siteConfig.contactEmail;

    if (!apiKey) {
      console.log("[DEV MODE CONTACT BRIEF]", JSON.stringify(data, null, 2));
      return NextResponse.json({
        ok: true,
        mode: "dev-console",
      });
    }

    const resend = new Resend(apiKey);
    await resend.emails.send({
      from: `${siteConfig.brandName} <onboarding@resend.dev>`,
      to: [toEmail],
      replyTo: data.email,
      subject: `New IT Consultancy Brief: ${data.name} (${data.engagementModel})`,
      text: [
        `Name: ${data.name}`,
        `Email: ${data.email}`,
        `Company: ${data.company || "N/A"}`,
        `Services: ${data.services.join(", ")}`,
        `Model: ${data.engagementModel}`,
        `Timeline: ${data.timeline}`,
        `Budget: ${data.budgetRange}`,
        "",
        "Technical Brief:",
        data.brief,
      ].join("\n"),
    });

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("Contact API error:", err);
    return NextResponse.json(
      { error: "Unable to process request right now. Please email directly." },
      { status: 500 }
    );
  }
}
