"use client";

import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  AlertCircle,
  Calendar,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Loader2,
  Send,
} from "lucide-react";
import { contactFormSchema, type ContactFormValues } from "@/lib/schema";
import { services } from "@/content/services";
import { engagementModels } from "@/content/engagement-models";
import { siteConfig } from "@/config/site";

const timelines = ["Immediate (< 2 Weeks)", "Within 30 Days", "1–3 Months", "Flexible / Exploring"];
const budgetBands = ["Under $5k (Focused Audit)", "$5k – $15k", "$15k – $35k", "$35k+ / Retainer"];

export function ContactIntakeForm() {
  const searchParams = useSearchParams();
  const initialTab = searchParams.get("tab") === "book" ? "book" : "brief";
  const initialModel = searchParams.get("model") || "implementation";

  const [activeTab, setActiveTab] = useState<"brief" | "book">(initialTab);
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState<string>("");

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    trigger,
    formState: { errors },
  } = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      services: ["Cloud Architecture & Migration"],
      engagementModel:
        engagementModels.find((m) => m.id === initialModel)?.name ||
        "End-to-End Implementation",
      timeline: "Within 30 Days",
      budgetRange: "$5k – $15k",
      name: "",
      email: "",
      company: "",
      brief: "",
      website: "",
    },
  });

  const selectedServices = watch("services");
  const selectedModel = watch("engagementModel");
  const selectedTimeline = watch("timeline");
  const selectedBudget = watch("budgetRange");

  const toggleService = (title: string) => {
    const exists = selectedServices.includes(title);
    const updated = exists
      ? selectedServices.filter((s) => s !== title)
      : [...selectedServices, title];
    setValue("services", updated, { shouldValidate: true });
  };

  const nextStep = async () => {
    if (step === 1) {
      const ok = await trigger(["services"]);
      if (ok) setStep(2);
    } else if (step === 2) {
      const ok = await trigger(["engagementModel", "timeline", "budgetRange"]);
      if (ok) setStep(3);
    }
  };

  const onSubmit = async (data: ContactFormValues) => {
    setStatus("submitting");
    setErrorMsg("");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || "Failed to send inquiry.");
      }
      setStatus("success");
    } catch (err) {
      setStatus("error");
      setErrorMsg(err instanceof Error ? err.message : "Something went wrong.");
    }
  };

  return (
    <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface-1)] p-6 lg:p-8">
      {/* Mode Switcher */}
      <div className="mb-8 inline-flex rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface-2)] p-1">
        <button
          type="button"
          onClick={() => setActiveTab("brief")}
          className={`inline-flex cursor-pointer items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold transition-colors ${
            activeTab === "brief"
              ? "bg-[var(--accent-primary)] text-[#090B10]"
              : "text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
          }`}
        >
          <Send className="h-3.5 w-3.5" />
          <span>Send Project Brief</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("book")}
          className={`inline-flex cursor-pointer items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold transition-colors ${
            activeTab === "book"
              ? "bg-[var(--accent-primary)] text-[#090B10]"
              : "text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
          }`}
        >
          <Calendar className="h-3.5 w-3.5" />
          <span>Book 30-Min Discovery Call</span>
        </button>
      </div>

      {activeTab === "book" ? (
        <div className="space-y-4 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface-2)] p-6">
          <span className="font-mono text-xs text-[var(--accent-primary)]">
            CAL.COM // DISCOVERY SESSION
          </span>
          <h3 className="font-display text-xl font-semibold text-[var(--text-primary)]">
            Schedule a 30-Minute Technical Architecture Call
          </h3>
          <p className="text-sm leading-relaxed text-[var(--text-secondary)]">
            Zero-pitch conversation with {siteConfig.founderName}. Walk through your current stack, bottlenecks, and timeline—and leave with candid architectural next steps.
          </p>
          <div className="pt-2">
            <a
              href={siteConfig.calBookingUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex h-11 items-center gap-2 rounded-lg bg-[var(--accent-primary)] px-5 text-sm font-semibold text-[#090B10] transition-colors hover:bg-[var(--accent-primary-hover)]"
            >
              <span>Open Live Calendar</span>
              <ExternalLink className="h-4 w-4" />
            </a>
          </div>
          <p className="font-mono text-[11px] text-[var(--text-muted)]">
            Update NEXT_PUBLIC_CAL_LINK in .env.local to connect your live Cal.com URL.
          </p>
        </div>
      ) : status === "success" ? (
        <div className="space-y-4 rounded-xl border border-[var(--status-success)]/40 bg-[var(--bg-surface-2)] p-8 text-center">
          <CheckCircle2 className="mx-auto h-10 w-10 text-[var(--status-success)]" />
          <h3 className="font-display text-2xl font-semibold text-[var(--text-primary)]">
            Brief Received
          </h3>
          <p className="mx-auto max-w-md text-sm text-[var(--text-secondary)]">
            Thank you. {siteConfig.founderName} reviews every technical brief directly and will reply within 1 business day.
          </p>
          <button
            type="button"
            onClick={() => {
              setStatus("idle");
              setStep(1);
            }}
            className="mt-2 inline-flex h-10 cursor-pointer items-center rounded-lg border border-[var(--border-strong)] px-4 text-xs font-medium text-[var(--text-primary)] hover:border-[var(--accent-primary)]"
          >
            Submit Another Inquiry
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6" noValidate>
          {/* Step Indicator */}
          <div className="flex items-center justify-between border-b border-[var(--border-subtle)] pb-4 font-mono text-xs">
            <span className="text-[var(--accent-primary)]">
              STEP 0{step} / 03
            </span>
            <span className="text-[var(--text-muted)]">
              {step === 1
                ? "CAPABILITY SCOPE"
                : step === 2
                  ? "ENGAGEMENT & TIMELINE"
                  : "CONTACT DETAILS"}
            </span>
          </div>

          {step === 1 && (
            <div className="space-y-4">
              <label className="block text-sm font-medium text-[var(--text-primary)]">
                Which IT consultancy areas do you need help with?
              </label>
              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                {services.map((service) => {
                  const checked = selectedServices.includes(service.title);
                  return (
                    <button
                      key={service.id}
                      type="button"
                      onClick={() => toggleService(service.title)}
                      className={`cursor-pointer rounded-xl border p-3.5 text-left transition-colors ${
                        checked
                          ? "border-[var(--accent-primary)] bg-[var(--bg-surface-2)]"
                          : "border-[var(--border-subtle)] bg-[var(--bg-canvas)] hover:border-[var(--border-strong)]"
                      }`}
                    >
                      <span className="font-mono text-[10px] text-[var(--accent-primary)]">
                        {service.index} //
                      </span>
                      <span className="mt-1 block text-sm font-medium text-[var(--text-primary)]">
                        {service.title}
                      </span>
                    </button>
                  );
                })}
              </div>
              {errors.services && (
                <p className="text-xs text-[var(--status-error)]">
                  {errors.services.message}
                </p>
              )}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-[var(--text-primary)]">
                  Preferred Engagement Model
                </label>
                <div className="mt-2.5 grid grid-cols-1 gap-2.5 sm:grid-cols-3">
                  {engagementModels.map((model) => (
                    <button
                      key={model.id}
                      type="button"
                      onClick={() =>
                        setValue("engagementModel", model.name, { shouldValidate: true })
                      }
                      className={`cursor-pointer rounded-xl border p-3 text-left text-xs font-medium transition-colors ${
                        selectedModel === model.name
                          ? "border-[var(--accent-primary)] bg-[var(--bg-surface-2)] text-[var(--text-primary)]"
                          : "border-[var(--border-subtle)] text-[var(--text-secondary)] hover:border-[var(--border-strong)]"
                      }`}
                    >
                      {model.name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[var(--text-primary)]">
                  Target Timeline
                </label>
                <div className="mt-2.5 flex flex-wrap gap-2">
                  {timelines.map((item) => (
                    <button
                      key={item}
                      type="button"
                      onClick={() => setValue("timeline", item, { shouldValidate: true })}
                      className={`cursor-pointer rounded-full border px-3.5 py-1.5 text-xs font-medium transition-colors ${
                        selectedTimeline === item
                          ? "border-[var(--accent-primary)] bg-[var(--accent-primary)] text-[#090B10]"
                          : "border-[var(--border-subtle)] text-[var(--text-secondary)] hover:border-[var(--border-strong)]"
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[var(--text-primary)]">
                  Estimated Budget Band
                </label>
                <div className="mt-2.5 flex flex-wrap gap-2">
                  {budgetBands.map((band) => (
                    <button
                      key={band}
                      type="button"
                      onClick={() =>
                        setValue("budgetRange", band, { shouldValidate: true })
                      }
                      className={`cursor-pointer rounded-full border px-3.5 py-1.5 text-xs font-medium transition-colors ${
                        selectedBudget === band
                          ? "border-[var(--accent-primary)] bg-[var(--accent-primary)] text-[#090B10]"
                          : "border-[var(--border-subtle)] text-[var(--text-secondary)] hover:border-[var(--border-strong)]"
                      }`}
                    >
                      {band}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              {/* Hidden Honeypot */}
              <input
                type="text"
                tabIndex={-1}
                autoComplete="off"
                {...register("website")}
                className="hidden"
              />
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-[var(--text-secondary)]">
                    Your Name *
                  </label>
                  <input
                    {...register("name")}
                    placeholder="Jordan Patel"
                    className="h-11 w-full rounded-xl border border-[var(--border-strong)] bg-[var(--bg-canvas)] px-3.5 text-sm text-[var(--text-primary)] placeholder:text-[var(--text-muted)]"
                  />
                  {errors.name && (
                    <p className="mt-1 text-xs text-[var(--status-error)]">
                      {errors.name.message}
                    </p>
                  )}
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-[var(--text-secondary)]">
                    Work Email *
                  </label>
                  <input
                    type="email"
                    {...register("email")}
                    placeholder="jordan@company.com"
                    className="h-11 w-full rounded-xl border border-[var(--border-strong)] bg-[var(--bg-canvas)] px-3.5 text-sm text-[var(--text-primary)] placeholder:text-[var(--text-muted)]"
                  />
                  {errors.email && (
                    <p className="mt-1 text-xs text-[var(--status-error)]">
                      {errors.email.message}
                    </p>
                  )}
                </div>
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-medium text-[var(--text-secondary)]">
                  Company / Organization (Optional)
                </label>
                <input
                  {...register("company")}
                  placeholder="Acme Cloud Inc."
                  className="h-11 w-full rounded-xl border border-[var(--border-strong)] bg-[var(--bg-canvas)] px-3.5 text-sm text-[var(--text-primary)] placeholder:text-[var(--text-muted)]"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-medium text-[var(--text-secondary)]">
                  Technical Context & Goals *
                </label>
                <textarea
                  rows={4}
                  {...register("brief")}
                  placeholder="Share your current stack, key bottlenecks, or compliance/scaling targets..."
                  className="w-full rounded-xl border border-[var(--border-strong)] bg-[var(--bg-canvas)] p-3.5 text-sm text-[var(--text-primary)] placeholder:text-[var(--text-muted)]"
                />
                {errors.brief && (
                  <p className="mt-1 text-xs text-[var(--status-error)]">
                    {errors.brief.message}
                  </p>
                )}
              </div>
            </div>
          )}

          {status === "error" && (
            <div className="flex items-center gap-2 rounded-xl border border-[var(--status-error)]/40 bg-[var(--status-error)]/10 px-4 py-3 text-xs text-[var(--status-error)]">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="flex items-center justify-between border-t border-[var(--border-subtle)] pt-5">
            {step > 1 ? (
              <button
                type="button"
                onClick={() => setStep((prev) => (prev - 1) as 1 | 2 | 3)}
                className="inline-flex h-11 cursor-pointer items-center gap-1.5 rounded-lg border border-[var(--border-strong)] px-4 text-sm font-medium text-[var(--text-primary)] hover:border-[var(--accent-primary)]"
              >
                <ChevronLeft className="h-4 w-4" />
                <span>Back</span>
              </button>
            ) : (
              <span className="font-mono text-[11px] text-[var(--text-muted)]">
                NDA AVAILABLE ON REQUEST
              </span>
            )}

            {step < 3 ? (
              <button
                type="button"
                onClick={nextStep}
                className="inline-flex h-11 cursor-pointer items-center gap-1.5 rounded-lg bg-[var(--accent-primary)] px-5 text-sm font-semibold text-[#090B10] transition-colors hover:bg-[var(--accent-primary-hover)]"
              >
                <span>Continue</span>
                <ChevronRight className="h-4 w-4" />
              </button>
            ) : (
              <button
                type="submit"
                disabled={status === "submitting"}
                className="inline-flex h-11 cursor-pointer items-center gap-2 rounded-lg bg-[var(--accent-primary)] px-6 text-sm font-semibold text-[#090B10] transition-colors hover:bg-[var(--accent-primary-hover)] disabled:opacity-60"
              >
                {status === "submitting" ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Sending...</span>
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" />
                    <span>Submit Technical Brief</span>
                  </>
                )}
              </button>
            )}
          </div>
        </form>
      )}
    </div>
  );
}
