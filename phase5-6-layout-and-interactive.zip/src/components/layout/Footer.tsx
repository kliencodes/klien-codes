"use client";

import { useState } from "react";
import Link from "next/link";
import { Check, Copy, Github, Linkedin } from "lucide-react";
import { footerColumns } from "@/config/navigation";
import { siteConfig } from "@/config/site";
import { Logo } from "@/components/brand/Logo";
import { AvailabilityBadge } from "@/components/brand/AvailabilityBadge";
import { copyToClipboard } from "@/lib/utils";

export function Footer() {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    const ok = await copyToClipboard(siteConfig.contactEmail);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <footer className="border-t border-[var(--border-subtle)] bg-[var(--bg-surface-1)]">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-12">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-12">
          <div className="space-y-4 lg:col-span-4">
            <Logo />
            <p className="max-w-sm text-sm leading-relaxed text-[var(--text-secondary)]">
              {siteConfig.description}
            </p>
            <AvailabilityBadge />
          </div>

          <div className="lg:col-span-3">
            <h3 className="font-mono text-xs font-semibold tracking-wider text-[var(--text-muted)] uppercase">
              01 // Services
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm">
              {footerColumns.services.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-[var(--text-secondary)] transition-colors hover:text-[var(--accent-primary)]"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-2">
            <h3 className="font-mono text-xs font-semibold tracking-wider text-[var(--text-muted)] uppercase">
              02 // Navigation
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm">
              {footerColumns.company.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-[var(--text-secondary)] transition-colors hover:text-[var(--accent-primary)]"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4 lg:col-span-3">
            <h3 className="font-mono text-xs font-semibold tracking-wider text-[var(--text-muted)] uppercase">
              03 // Direct Contact
            </h3>
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface-2)] px-3 py-2 font-mono text-xs text-[var(--text-primary)] transition-colors hover:border-[var(--accent-primary)]"
            >
              <span>{siteConfig.contactEmail}</span>
              {copied ? (
                <Check className="h-3.5 w-3.5 text-[var(--status-success)]" />
              ) : (
                <Copy className="h-3.5 w-3.5 text-[var(--text-muted)]" />
              )}
            </button>
            <p className="text-xs text-[var(--text-muted)]">
              {siteConfig.locationTz}
            </p>
            <div className="flex items-center gap-2.5 pt-1">
              <a
                href={siteConfig.socialLinks.github}
                target="_blank"
                rel="noreferrer"
                aria-label="GitHub"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-[var(--border-subtle)] text-[var(--text-secondary)] transition-colors hover:border-[var(--accent-primary)] hover:text-[var(--text-primary)]"
              >
                <Github className="h-4 w-4" />
              </a>
              <a
                href={siteConfig.socialLinks.linkedin}
                target="_blank"
                rel="noreferrer"
                aria-label="LinkedIn"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-[var(--border-subtle)] text-[var(--text-secondary)] transition-colors hover:border-[var(--accent-primary)] hover:text-[var(--text-primary)]"
              >
                <Linkedin className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-start justify-between gap-4 border-t border-[var(--border-subtle)] pt-8 text-xs text-[var(--text-muted)] sm:flex-row sm:items-center">
          <p>
            © {new Date().getFullYear()} {siteConfig.brandName}. All rights reserved.
          </p>
          <p className="font-mono">
            PRESS <span className="text-[var(--text-primary)]">⌘K</span> FOR QUICK NAVIGATION
          </p>
        </div>
      </div>
    </footer>
  );
}
