"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useTheme } from "next-themes";
import {
  ArrowRight,
  Calendar,
  Check,
  Copy,
  Moon,
  Search,
  Sun,
  Terminal,
  X,
} from "lucide-react";
import { mainNav } from "@/config/navigation";
import { siteConfig } from "@/config/site";
import { services } from "@/content/services";
import { copyToClipboard } from "@/lib/utils";

interface PaletteItem {
  id: string;
  group: "Pages" | "Services" | "Quick Actions";
  label: string;
  hint: string;
  action: () => void;
}

export function CommandPalette() {
  const router = useRouter();
  const { resolvedTheme, setTheme } = useTheme();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((prev) => !prev);
      } else if (e.key === "Escape") {
        setOpen(false);
      }
    };
    const onCustomOpen = () => setOpen(true);

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("open-command-palette", onCustomOpen);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("open-command-palette", onCustomOpen);
    };
  }, []);

  const items: PaletteItem[] = useMemo(() => {
    const pageItems: PaletteItem[] = [
      {
        id: "page-home",
        group: "Pages",
        label: "Home",
        hint: "/",
        action: () => {
          router.push("/");
          setOpen(false);
        },
      },
      ...mainNav.map((item) => ({
        id: `page-${item.href}`,
        group: "Pages" as const,
        label: item.label,
        hint: item.description || item.href,
        action: () => {
          router.push(item.href);
          setOpen(false);
        },
      })),
      {
        id: "page-contact",
        group: "Pages",
        label: "Start a Project / Contact",
        hint: "/contact",
        action: () => {
          router.push("/contact");
          setOpen(false);
        },
      },
    ];

    const serviceItems: PaletteItem[] = services.map((service) => ({
      id: `service-${service.slug}`,
      group: "Services",
      label: `${service.index} // ${service.title}`,
      hint: service.typicalTimeline,
      action: () => {
        router.push(`/services/${service.slug}`);
        setOpen(false);
      },
    }));

    const quickActions: PaletteItem[] = [
      {
        id: "action-copy-email",
        group: "Quick Actions",
        label: copied ? "Email Copied to Clipboard" : `Copy ${siteConfig.contactEmail}`,
        hint: "Clipboard",
        action: async () => {
          const ok = await copyToClipboard(siteConfig.contactEmail);
          if (ok) {
            setCopied(true);
            setTimeout(() => setCopied(false), 1800);
          }
        },
      },
      {
        id: "action-toggle-theme",
        group: "Quick Actions",
        label: resolvedTheme === "dark" ? "Switch to Light Mode" : "Switch to Dark Mode",
        hint: "Theme",
        action: () => {
          setTheme(resolvedTheme === "dark" ? "light" : "dark");
          setOpen(false);
        },
      },
      {
        id: "action-book-call",
        group: "Quick Actions",
        label: "Book 30-Min Architecture Call",
        hint: "Discovery",
        action: () => {
          router.push("/contact?tab=book");
          setOpen(false);
        },
      },
    ];

    return [...quickActions, ...pageItems, ...serviceItems];
  }, [copied, resolvedTheme, router, setTheme]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter(
      (item) =>
        item.label.toLowerCase().includes(q) ||
        item.hint.toLowerCase().includes(q) ||
        item.group.toLowerCase().includes(q)
    );
  }, [items, query]);

  useEffect(() => {
    setActiveIndex(0);
  }, [query, open]);

  if (!open) return null;

  const handleListKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((prev) => (filtered.length ? (prev + 1) % filtered.length : 0));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((prev) =>
        filtered.length ? (prev - 1 + filtered.length) % filtered.length : 0
      );
    } else if (e.key === "Enter" && filtered[activeIndex]) {
      e.preventDefault();
      filtered[activeIndex].action();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center bg-black/65 px-4 pt-[12vh] backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Command Palette"
      onClick={() => setOpen(false)}
    >
      <div
        className="w-full max-w-lg overflow-hidden rounded-2xl border border-[var(--border-strong)] bg-[var(--bg-surface-1)] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={handleListKeyDown}
      >
        <div className="flex items-center gap-3 border-b border-[var(--border-subtle)] px-4 py-3.5">
          <Search className="h-4 w-4 shrink-0 text-[var(--accent-primary)]" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Jump to page, service, or action..."
            className="w-full bg-transparent text-sm text-[var(--text-primary)] placeholder:text-[var(--text-muted)] focus:outline-none"
          />
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label="Close command palette"
            className="rounded-md p-1 text-[var(--text-muted)] hover:text-[var(--text-primary)]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="max-h-80 overflow-y-auto p-2">
          {filtered.length === 0 ? (
            <div className="px-4 py-8 text-center font-mono text-xs text-[var(--text-muted)]">
              NO_MATCHING_ROUTES // TRY &quot;CLOUD&quot;, &quot;WORK&quot;, OR &quot;CALL&quot;
            </div>
          ) : (
            filtered.map((item, idx) => {
              const active = idx === activeIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onMouseEnter={() => setActiveIndex(idx)}
                  onClick={item.action}
                  className={`flex w-full cursor-pointer items-center justify-between rounded-xl px-3 py-2.5 text-left text-sm transition-colors ${
                    active
                      ? "bg-[var(--bg-surface-2)] text-[var(--text-primary)]"
                      : "text-[var(--text-secondary)] hover:bg-[var(--bg-surface-2)]"
                  }`}
                >
                  <span className="flex items-center gap-2.5 truncate">
                    {item.id === "action-copy-email" ? (
                      copied ? (
                        <Check className="h-4 w-4 text-[var(--status-success)]" />
                      ) : (
                        <Copy className="h-4 w-4 text-[var(--accent-primary)]" />
                      )
                    ) : item.id === "action-toggle-theme" ? (
                      resolvedTheme === "dark" ? (
                        <Sun className="h-4 w-4 text-[var(--accent-primary)]" />
                      ) : (
                        <Moon className="h-4 w-4 text-[var(--accent-primary)]" />
                      )
                    ) : item.id === "action-book-call" ? (
                      <Calendar className="h-4 w-4 text-[var(--accent-primary)]" />
                    ) : (
                      <Terminal className="h-3.5 w-3.5 text-[var(--text-muted)]" />
                    )}
                    <span className="truncate font-medium">{item.label}</span>
                  </span>
                  <span className="ml-3 flex shrink-0 items-center gap-2 font-mono text-[11px] text-[var(--text-muted)]">
                    <span>{item.hint}</span>
                    {active && <ArrowRight className="h-3.5 w-3.5 text-[var(--accent-primary)]" />}
                  </span>
                </button>
              );
            })
          )}
        </div>

        <div className="flex items-center justify-between border-t border-[var(--border-subtle)] bg-[var(--bg-surface-2)] px-4 py-2 font-mono text-[11px] text-[var(--text-muted)]">
          <span>↑↓ Navigate · ↵ Select · ESC Close</span>
          <span>SYS.NAV // ⌘K</span>
        </div>
      </div>
    </div>
  );
}
